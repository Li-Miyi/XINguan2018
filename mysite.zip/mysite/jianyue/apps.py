from django.apps import AppConfig


class JianyueConfig(AppConfig):
    name = 'jianyue'
